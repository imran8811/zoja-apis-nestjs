import { Document } from 'mongoose';

export interface IUser extends Document{
    readonly fullName: string;
    readonly gender: string;
    readonly email: string;
    readonly password: string;
    readonly state: number;
    readonly favouriteProfiles: string[];
    readonly membership: boolean;
    readonly profileScore: number;
}