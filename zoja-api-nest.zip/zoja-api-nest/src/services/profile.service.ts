import { Injectable } from '@nestjs/common';

@Injectable()
export class ProfileService {
  getProfiles(): string {
    return 'Hello World!';
  }


}
