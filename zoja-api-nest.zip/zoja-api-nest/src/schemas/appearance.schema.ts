import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { HydratedDocument } from 'mongoose';

export type userDocument = HydratedDocument<Appearance>;

@Schema()
export class Appearance {

    @Prop()
    userId : string;
    
    @Prop()
    age : number;

    @Prop()
    complexion : string;
    
    @Prop()
    weight : number;
    
    @Prop()
    feet : number;
    
    @Prop()
    inch : number;
    
    @Prop()
    headType : string;
    
} 

export const UserSchema = SchemaFactory.createForClass(Appearance)