import { Controller, Get, Res, Body, Post, HttpStatus } from '@nestjs/common';
import { UserDTO } from 'src/dtos/user.dto';
import { UserService } from 'src/services/user.service';

@Controller('user')
export class UserController {
  constructor(private readonly userService: UserService) {}

  @Post('create')
  async createNewUser(@Res() response, @Body() userDTO: UserDTO) {
    try {
      const userCreated = await this.userService.createUser(userDTO);
      return response.status(HttpStatus.CREATED).json({
        type: 'success',
        message: 'User has been created successfully',
        favouriteProfiles: userCreated.favouriteProfiles,
        profileScore: userCreated.profileScore,
        fullName: userCreated.fullName
      });
    } catch (err) {
      return response.status(HttpStatus.BAD_REQUEST).json({
        statusCode: 400,
        message: 'Error: User not created!',
        error: err
      })
    }
  }

  @Get('all')
  getAllUsers() {
    return this.userService.getAllUsers();
  }
}
