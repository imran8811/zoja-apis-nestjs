import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { HydratedDocument } from 'mongoose';

export type userDocument = HydratedDocument<User>;

@Schema()
export class User {
    @Prop({required: true})
    fullName : string;
    
    @Prop({required: true})
    gender : string;

    @Prop({
        required: true,
        unique: true
    })
    email : string;
    
    @Prop({required: true})
    password : string;
    
    @Prop()
    state : number;
    
    @Prop()
    favouriteProfiles : string[];
    
    @Prop()
    membership : boolean;
    
    @Prop()
    profileScore : number;
} 

export const UserSchema = SchemaFactory.createForClass(User)