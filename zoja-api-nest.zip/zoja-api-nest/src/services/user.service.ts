import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';

import { User, UserSchema } from 'src/schemas/user.schema';
import { UserDTO } from 'src/dtos/user.dto';
import { IUser } from 'src/interfaces/user.interface';

@Injectable()
export class UserService {
  
  constructor(@InjectModel('User') private userModel: Model<UserDTO>){}
  
  async createUser(crateUserDTO: UserDTO): Promise<IUser> {
    const newUser = new this.userModel(crateUserDTO);
    return newUser.save();    
  }

  async getAllUsers() {
    const userData = await this.userModel.find();
    if (!userData || userData.length == 0) {
      throw new NotFoundException('Users data not found!');
    }
    return userData;
  }


}
