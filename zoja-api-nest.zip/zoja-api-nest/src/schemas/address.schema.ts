import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { HydratedDocument } from 'mongoose';

export type userDocument = HydratedDocument<Address>;

@Schema()
export class Address {

    @Prop()
    userId : string;
    
    @Prop()
    currentAddessArea : string;

    @Prop()
    currentAddessCity : string;
    
    @Prop()
    currentAddessCountry : string;
    
    @Prop()
    permanentAddessArea : string;
    
    @Prop()
    permanentAddessCity : string;
    
    @Prop()
    permanentAddessCountry : string;
    
} 

export const AddressSchema = SchemaFactory.createForClass(Address)