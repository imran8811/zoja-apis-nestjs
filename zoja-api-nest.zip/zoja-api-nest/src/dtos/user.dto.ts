import { IsArray, IsBoolean, IsEmail, IsNotEmpty, IsNumber, IsString, MaxLength } from "class-validator";

export class UserDTO {
    @IsString()
    @IsNotEmpty()
    readonly fullName: string;

    @IsString()
    @IsNotEmpty()
    readonly gender : string;

    @IsEmail()
    @IsNotEmpty()
    readonly email : string;

    @IsString()
    @IsNotEmpty()
    password : string;
    
    @IsNumber()
    @IsNotEmpty()
    state : number;

    @IsArray()
    @IsNotEmpty()
    favouriteProfiles : string[];
    
    @IsBoolean()
    @IsNotEmpty()
    membership : boolean;
    
    @IsNumber()
    @IsNotEmpty()
    profileScore : number;
}